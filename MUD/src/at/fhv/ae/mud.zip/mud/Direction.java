package at.fhv.ae.mud;

public enum Direction {
    NORTH,
    EAST,
    SOUTH,
    WEST;
}
