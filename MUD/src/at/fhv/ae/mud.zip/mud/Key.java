package at.fhv.ae.mud;

public class Key extends Item{
    public Key(String name) {
        super(name);
    }

    public Key(String name, String description) {
        super(name, description);
    }

}
